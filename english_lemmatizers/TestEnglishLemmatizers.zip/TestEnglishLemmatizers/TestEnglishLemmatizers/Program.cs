﻿using System;
using System.IO;
using edu.stanford.nlp.ling;
using edu.stanford.nlp.pipeline;
using edu.stanford.nlp.util;
using ikvm.extensions;
using java.util;

namespace TestEnglishLemmatizers
{
    class Program
    {
        static void Main(string[] args)
        {
            //https://sergey-tihon.github.io/Stanford.NLP.NET/StanfordCoreNLP.html
            const string jarRoot = @"D:\Libraries/stanford-corenlp-full-2014-06-16/";
            const string text = "Kosgi Santosh sent an email to Stanford University. He didn't get a reply. Walking walk walked";

            var props = new Properties();
            props.setProperty("annotators", "tokenize, ssplit, pos, lemma");
            props.setProperty("sutime.binders", "0");

            //extracted from stanford-corenlp-3.4-models.jar
            props.setProperty("pos.model",
                              @"src/stanford-corenlp-3.4-models/edu/stanford/nlp/models/pos-tagger/english-left3words/english-left3words-distsim.tagger");

            var curDir = Environment.CurrentDirectory;
            Directory.SetCurrentDirectory(jarRoot);
            var pipeline = new StanfordCoreNLP(props);
            Directory.SetCurrentDirectory(curDir);

            //excecute
            var annotation = new Annotation(text);
            pipeline.annotate(annotation);
            
            //get data
            var tokenClass = ExtensionMethods.getClass(new CoreAnnotations.TokensAnnotation());
            var tokens = (AbstractList)annotation.get(tokenClass);
            foreach (ArrayCoreMap token in tokens)
            {
                var posClass = ExtensionMethods.getClass(new CoreAnnotations.PartOfSpeechAnnotation());
                var lemmaClass = ExtensionMethods.getClass(new CoreAnnotations.LemmaAnnotation());
                var textClass = ExtensionMethods.getClass(new CoreAnnotations.OriginalTextAnnotation());

                var word = token.get(textClass);
                var pos = token.get(posClass); //documentation of the pos tags (Pennsylvania (Penn) Treebank Tag-set): https://www.ling.upenn.edu/courses/Fall_2003/ling001/penn_treebank_pos.html, http://www.comp.leeds.ac.uk/amalgam/tagsets/upenn.html
                var lemma = token.get(lemmaClass);

                Console.WriteLine("Text: {0} \t , POS: {1} \t , Lemma: {2}", word, pos, lemma);
                //TODO: save pos and lemma....

            }
        }
    }
}
